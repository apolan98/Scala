object First_tasl {
def main(args: Array[String]): Unit = {

  println("Hello, world")
}
}
