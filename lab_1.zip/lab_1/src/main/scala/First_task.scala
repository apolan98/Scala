class First_task {

}
