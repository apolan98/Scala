object Pr1_6 {
  def isPalindrome[A](ls: List[A]): Boolean = ls == ls.reverse

  def main (args: Array[String]): Unit = {
    println (isPalindrome(List(1, 2, 3, 2, 1)))
    println (isPalindrome(List(1, 2, 3, 2, 3)))
  }

}
