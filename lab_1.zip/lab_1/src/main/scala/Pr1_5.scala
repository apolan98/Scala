object Pr1_5 {
  def reverse[A](ls: List[A]): List[A] = ls.reverse

  def main (args: Array[String]) {
    print (reverse(List(1, 1, 2, 3, 5, 8)))
  }
}